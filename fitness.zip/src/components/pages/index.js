export { default as Home } from "./Home";
export { default as UserProfile } from "./UserProfile";
export { default as DailyGoals } from "./DailyGoals";
export { default as WeightTracking } from "./WeightTracking";

// console.log("index.js");
// import Home from "./Home";
// import UserProfile from "./UserProfile";
// import DailyGoals from "./DailyGoals";
// import WeightTracking from "./WeightTracking";
// export default { Home, UserProfile, DailyGoals, WeightTracking };
