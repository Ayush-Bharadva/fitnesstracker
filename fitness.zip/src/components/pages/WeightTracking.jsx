import React from "react";
import Main from "../UI/Main";

function WeightTracking() {
	return (
		<Main>
			<h1 className="weight-tracking">WeightTracking</h1>
		</Main>
	);
}

export default WeightTracking;
