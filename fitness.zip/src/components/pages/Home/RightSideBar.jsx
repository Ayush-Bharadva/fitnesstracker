import React from "react";
import "../../../App.scss";

function RightSideBar({ children }) {
	return <div className="sidebar right">{children}</div>;
}

export default RightSideBar;
