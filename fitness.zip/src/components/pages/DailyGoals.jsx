import React from "react";
import Main from "../UI/Main";

function DailyGoals() {
	return (
		<Main>
			<h1 className="daily-goals">DailyGoals</h1>
		</Main>
	);
}

export default DailyGoals;
